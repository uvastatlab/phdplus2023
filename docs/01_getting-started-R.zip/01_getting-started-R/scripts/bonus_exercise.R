download.file("https://gist.githubusercontent.com/slopp/ce3b90b9168f2f921784de84fa445651/raw/4ecf3041f0ed4913e7c230758733948bc561f434/penguins.csv",
              "data-raw/penguins.csv", mode = "wb")

# import data


# view data


# print out first few rows


# get summary


# average body mass in g


# number of penguins with flipper length greather than 200mm


# table showing the number of penguins by island
